library(qs)
library(rstudioapi)
library(shiny)
library(ComplexUpset)
library(data.table)
library(rclipboard)
library(ggplot2)


# ---- Internal functions (as provided) ----
wd <- dirname(getActiveDocumentContext()$path)
setwd(wd)
signature_lists <- qread(paste0(wd, "/CpG_sets.qs"))

CpG_ORA <- function(input, background, confidence_level) {
  signature_list <- signature_lists[[confidence_level]]
  results <- data.frame(row.names = names(signature_list))
  for (set_name in names(signature_list)) {
    set <- signature_list[[set_name]]
    set <- intersect(set, background)
    set_intersect <- intersect(input, set)
    set_union <- union(input, set)
    results[set_name, "Enriched CpGs"] <- paste0(set_intersect, collapse = "\n")
    results[set_name, "Odds Ratio"] <-
      ((length(background) - length(set_union)) * length(set_intersect)) /
      ((length(set) - length(set_intersect)) * (length(input) - length(set_intersect)))
    results[set_name, "P-value"] <- phyper(
      q        = length(set_intersect) - 1,
      m        = length(input),
      n        = length(background) - length(input),
      k        = length(set),
      lower.tail = FALSE
    )
    results[set_name, "Overlap"] <- length(set_intersect)
    results[set_name, "Expected Count"] <- (length(set) / length(background)) * length(input)
    results[set_name, "Set Size"] <- length(set)
  }
  results$qvalue <- p.adjust(results$`P-value`, method = "bonferroni")
  return(results)
}

plot_CpG_UpSet <- function(ORA_result) {
  tmp <- strsplit(ORA_result$`Enriched CpGs`, split = "\n")
  names(tmp) <- rownames(ORA_result)
  list_input <- fromList(tmp)
  colnames(list_input) <- names(tmp)
  rownames(list_input) <- unique(unlist(tmp))
  list_input <- as.data.frame(list_input == 1)
  odds_ratios <- ORA_result$`Odds Ratio`
  names(odds_ratios) <- rownames(ORA_result)
  ComplexUpset:: upset(
    list_input,
    names(tmp),
    name = "CpG sets",
    base_annotations=list(
      'Intersection size'=intersection_size(counts=FALSE)
    ),
    min_size = 2, # change this to remove a tail of small intersects
    set_sizes = (
      upset_set_size() +
        ggplot2::scale_y_reverse(
          breaks = scales::pretty_breaks(n = 4)
        ) +
        theme(axis.text.x = element_text(angle = 90))
    ),
    width_ratio = 0.3)
}

# app.R
library(shiny)
library(UpSetR)
library(DT)
# set max upload size to 30 MB
options(shiny.maxRequestSize = 30 * 1024^2)

# ---- UI ----
ui <- fluidPage(
  rclipboardSetup(),  # Initialize clipboard support
  
  DTOutput("result_table"),
  fluidRow(
    column(
      width = 3,
      wellPanel(
        tags$h4("Input settings"),
        tags$strong("CpG list"),
        textAreaInput(
          inputId = "cpg_text",
          label   = NULL,
          placeholder = "Paste one probe ID per line",
          rows    = 8
        ),
        fileInput(
          inputId = "cpg_file",
          label   = "or upload CpG list",
          multiple = FALSE,
          accept   = c(".txt", ".csv", ".tsv")
        ),
        tags$hr(),
        tags$strong("Background list"),
        textAreaInput(
          inputId = "bg_text",
          label   = NULL,
          placeholder = "Paste one probe ID per line",
          rows    = 8
        ),
        fileInput(
          inputId = "bg_file",
          label   = "or upload background list",
          multiple = FALSE,
          accept   = c(".txt", ".csv", ".tsv")
        ),
        fluidRow(
          column(
            width = 6,
            actionButton("load_epic", "EPIC", width = "100%")
          ),
          column(
            width = 6,
            actionButton("load_450k", "450K", width = "100%")
          )
        ),
        tags$hr(),
        tags$strong("Specificity"),
        radioButtons(
          inputId = "confidence_level",
          label   = NULL,
          choices = list(
            "High Specificity"   = 1,
            "Medium Specificity" = 2,
            "Low Specificity"    = 3
          ),
          selected = 2
        ),
        actionButton("analyze", "Analyze", width = "100%"),
        tags$hr(),
        actionButton("load_example", "Load Example", width = "100%")
      )
    ),
    column(
      width = 9,
      fluidRow(
        column(
          width = 12,
          plotOutput("upset_plot", height = "400px")
        )
      ),
      fluidRow(
        column(
          width = 12,
          DTOutput("result_table")
        )
      ),
      # Add this row for download buttons, bottom-right aligned
      fluidRow(
        column(
          width = 12,
          div(
            style = "display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px;",
            downloadButton("download_svg", "Download Plot (.svg)"),
            downloadButton("download_csv", "Download Table (.csv)")
          )
        )
      )
    )
  )
)

# ---- Server ----
server <- function(input, output, session) {
  # Reactive: CpG input vector
  cpg_list <- reactiveVal(character(0))
  observeEvent(input$cpg_file, {
    lines <- readLines(input$cpg_file$datapath)
    lines <- lines[nzchar(lines)]
    lines <- unlist(strsplit(lines, "[,\t\r\n]+"))
    lines <- gsub("\"|,| |\t", "", lines)
    lines <- grep("^cg\\d+$", lines, value = TRUE)
    updateTextAreaInput(
      session,
      "cpg_text",
      value = paste(lines, collapse = "\n")
    )
  })
  observeEvent(input$cpg_text, {
    txt <- unlist(strsplit(input$cpg_text, "[,\t\r\n]+"))
    txt = gsub("\"|,| |\t","",x = txt)
    txt <- txt[nzchar(txt)]
    cpg_list(txt)
  })
  # cpg_list <- reactive({
  #   if (!is.null(input$cpg_file)) {
  #     df <- readLines(input$cpg_file$datapath)
  #     #@RRR make sure gsub("\"|,| |\t","",x = df ) is in
  #     df <- df[nzchar(df)]
  #     return(df)
  #   }
  #   txt <- txt[nzchar(txt)]
  #   txt <- unlist(strsplit(input$cpg_text, "[\r\n,\t]+"))
  #   txt <- gsub("\"|,| |\t|\"","",x = txt )
  #   txt <- grep("^cg\\d+$", txt, value = TRUE)
  #   txt
  # })

  # After defining cpg_list reactive, add:

  # Reactive: Background vector
  bg_list <- reactiveVal(character(0))
  # After defining bg reactive, add:
  observeEvent(input$bg_file, {
    lines <- readLines(input$bg_file$datapath)
    lines <- lines[nzchar(lines)]
    lines <- unlist(strsplit(lines, "[,\t\r\n]+"))
    lines <- gsub("\"|,| |\t", "", lines)
    lines <- grep("^cg\\d+$", lines, value = TRUE)
    updateTextAreaInput(
      session,
      "bg_text",
      value = paste(lines, collapse = "\n")
    )
  })
  observeEvent(input$bg_text, {
    txt <- unlist(strsplit(input$bg_text, "[\r\n]+"))
    txt = gsub("\"|,| |\t","",x = txt )
    txt <- txt[nzchar(txt)]
    bg_list(txt)
  })
  observeEvent(input$load_epic, {
    # Assumes "EPIC_background.txt" exists in app directory
    epic <- fread("EPIC_background.txt", header = FALSE)[[1]]
    epic <- epic[nzchar(trimws(epic))]
    bg_list(epic)
    # Update bg_text input with the loaded file
    updateTextAreaInput(
      session,
      "bg_text",
      value = paste(epic, collapse = "\n")
    )
  })
  observeEvent(input$load_450k, {
    # Assumes "450k_background.txt" exists in app directory
    bg450k <- fread("450k_background.txt", header = FALSE)[[1]]
    bg450k <- bg450k[nzchar(trimws(bg450k))]
    bg_list(bg450k)
    # Update bg_text input with the loaded file
    updateTextAreaInput(
      session,
      "bg_text",
      value = paste(bg450k, collapse = "\n")
    )
  })
  observeEvent(input$load_example, {
    example_cpgs <- fread("example_input.txt", header = FALSE)[[1]]
    example_bg   <- fread("example_bg.txt", header = FALSE)[[1]]
    updateTextAreaInput(
      session,
      "cpg_text",
      value = paste(example_cpgs, collapse = "\n")
    )
    updateTextAreaInput(
      session,
      "bg_text",
      value = paste(example_bg, collapse = "\n")
    )
    bg_list(example_bg)
  })
  # Run ORA on analyze
  ora_result <- eventReactive(input$analyze, {
    req(cpg_list(), bg_list())
    CpG_ORA(
      input            = cpg_list(),
      background       = bg_list(),
      confidence_level = as.numeric(input$confidence_level)
    )
  })
  output$result_table <- renderDT({
    req(ora_result())
    dat <- ora_result()
    
    # Create copy button column
    dat$copy <- sprintf(
      '<button class="copy-btn btn btn-sm btn-default" style="margin-left: 10px;" data-clipboard-text="%s">Copy</button>',
      gsub('"', '"', dat$`Enriched CpGs`)  # Escape double quotes
    )
    
    # Truncate Enriched CpGs column
    dat$truncated_text <- mapply(function(x, y) {
      # Split the CpGs by newline and count them
      cpg_list <- strsplit(x, "\n")[[1]]
      
      # If there are more than 3 CpGs, show first three and add ellipsis
      if (length(cpg_list) > 3) {
        paste0(paste(cpg_list[1:3], collapse = "\n"), "\n...")
      } else {
        x
      }
    }, dat$`Enriched CpGs`, dat$copy)
    
    # Display truncated version but keep full text for copying
    dat$`Enriched Probes` <- dat$truncated_text
    
    # Render the table
    datatable(
      dat[,c("Enriched Probes", "copy", colnames(dat)[2:7])],
      escape = FALSE,
      options = list(
        pageLength = 10,
        autoWidth = TRUE,
        scrollX = TRUE,
        columnDefs = list(
          list(targets = 0, className = "dt-left"),
          list(targets = 1, orderable = FALSE, searchable = FALSE)
        )
      ),
      callback = JS("
      $(document).ready(function() {
        var clipboard = new ClipboardJS('.copy-btn');
        clipboard.on('success', function(e) {
          $(e.trigger).tooltip('show').attr('data-original-title', 'Copied!');
          setTimeout(function() {
            $(e.trigger).tooltip('hide');
          }, 2000);
        });
      });
    ")
    )%>%
      formatSignif(
        columns = c("Odds Ratio", "P-value", "Expected Count", "qvalue"),  # <- replace with your numeric column names
        digits = 4
      )
  })
  output$upset_plot <- renderPlot({
    req(ora_result())
    plot_CpG_UpSet(ora_result())
  })
  
  output$download_svg <- downloadHandler(
    filename = function() {
      "UpSet_Enrichment.svg"
    },
    content = function(file) {
      svg(file)
      print(plot_CpG_UpSet(ora_result()))
      dev.off()
    }
  )
  output$download_csv <- downloadHandler(
    filename = function() {
      "DNAm_enrichment_res.csv"
    },
    content = function(file) {
      write.csv(ora_result(), file = file, row.names = T)

    }
  )
}
shinyApp(ui, server)