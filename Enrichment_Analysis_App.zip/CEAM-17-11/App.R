library(qs)
#library(rstudioapi)
#library(shiny)
library(ComplexUpset)
library(data.table)
library(rclipboard)
library(ggplot2)


# ---- Internal functions (as provided) ----
#wd <- dirname(getActiveDocumentContext()$path)
#setwd(wd)
# signature_lists <- qread(paste0(wd, "/CpG_sets.qs"))
signature_lists <- qread("CpG_sets.qs")

CpG_ORA <- function(input, background, confidence_level) {
  signature_list <- signature_lists[[confidence_level]]
  results <- data.frame(row.names = names(signature_list))
  for (set_name in names(signature_list)) {
    set <- signature_list[[set_name]]
    set <- intersect(set, background)
    set_intersect <- intersect(input, set)
    set_union <- union(input, set)
    results[set_name, "Enriched CpGs"] <- paste0(set_intersect, collapse = "\n")
    if (((length(set) - length(set_intersect)) * (length(input) - length(set_intersect))) == 0 | length(set_intersect) == 0){
      results[set_name, "Odds Ratio"] <- as.character("Result not estimable")
    } else {

      results[set_name, "Odds Ratio"] <-      round(
        ((length(background) - length(set_union)) * length(set_intersect)) /
        ((length(set) - length(set_intersect)) * (length(input) - length(set_intersect)))
      , 2)
    }
    
    results[set_name, "P-value"] <- phyper(
      q        = length(set_intersect) - 1,
      m        = length(input),
      n        = length(background) - length(input),
      k        = length(set),
      lower.tail = FALSE
    )
    results[set_name, "Overlap"] <- length(set_intersect)
    results[set_name, "Expected Count"] <- (length(set) / length(background)) * length(input)
    results[set_name, "Set Size"] <- length(set)
  }
  results$qvalue <- p.adjust(results$`P-value`, method = "bonferroni")
  #results$qvalue <- pmin(results$`P-value` * 12, 1)
  return(results)
}

plot_CpG_UpSet <- function(ORA_result, min_set_size = 0) {
  ORA_result[!ORA_result$Overlap >= min_set_size, "Enriched CpGs"] <- ""
  tmp <- strsplit(ORA_result$`Enriched CpGs`, split = "\n")
  names(tmp) <- rownames(ORA_result)
  list_input <- fromList(tmp)
  names(list_input) <- names(tmp)
  rownames(list_input) <- unique(unlist(tmp))
  list_input <- as.data.frame(list_input == 1)
  odds_ratios <- ORA_result$`Odds Ratio`
  names(odds_ratios) <- rownames(ORA_result)
  ComplexUpset:: upset(
    list_input,
    names(tmp),
    name = "CpG sets",
    base_annotations=list(
      'Intersection size'=intersection_size(counts=FALSE)
    ),
    min_size = 2, # change this to remove a tail of small intersects
    set_sizes = (
      upset_set_size() +
        ggplot2::scale_y_reverse(
          breaks = scales::pretty_breaks(n = 4)
        ) +
        theme(axis.text.x = element_text(angle = 90))
    ),
    width_ratio = 0.3)
}

# app.R
library(shiny)
library(UpSetR)
library(DT)
# set max upload size to 30 MB
options(shiny.maxRequestSize = 30 * 1024^2)

# ---- UI ----

ui <- navbarPage(
  title = "CEAM",

# ---- PAGE 1: About ----
tabPanel("About",
         fluidPage(
           # Make sure Logo.png is in the www/ folder
           
           # Row with title and logo side-by-side
           fluidRow(
             column(
               width = 8,
               div(
                 style = "display: flex; align-items: center;",
                 h1("Welcome to CEAM: Cell-type Enrichment Analysis for Methylation", style = "margin: 0;")
               )
             ),
             column(
               width = 4,
               div(
                 style = "text-align: right; padding-top: 5px;",
                 tags$img(
                   src = "Logo.png",
                   style = "max-width: 100%; height: auto; max-height: 80px;",
                   alt = "Logo not found :("
                 )
               )
             )
           ),
           br(),
           
           # Second row: Main content below
           fluidRow(
             column(
               width = 12,
               h3("Introduction"),
               p(HTML("CEAM is an interactive tool for identifying cell type–specific DNA methylation (DNAm) signatures from bulk old-age brain EWAS results.
           Using reference CpG panels generated from nuclei-sorted human cortex across four major brain cell types: 
           <b>neurons (NEU)</b>, <b>microglia (MG)</b>, <b>oligodendrocytes (OLIG)</b>, and <b>astrocyte-enriched cells (AST)</b>.
           CEAM enables users to test whether their list of DMPs shows enrichment within any aforementioned cell type.")),
               
               br(),
               
               h3("How CEAM Works"),
               p(HTML("Upload a list of DMPs or EWAS summary results, select a background probe universe, and choose the cell-type specificity level.
           CEAM then performs a <b>modified over-representation analysis (ORA)</b> to test whether DMPs are enriched in CpGs specific to one or more brain cell types.
           <br><br>
           <b>Results include:</b>")),
               tags$ul(
                 tags$li("Odds ratios (OR) and p-values (raw + Bonferroni adjusted)"),
                 tags$li("Enrichment plots (UpSet plots)"),
                 tags$li("Optional hyper-/hypomethylation directionality (high-specificity sets only)"),
                 tags$li("Downloadable results (table + figure)")
               ),
               br(),
               fluidRow(
                 # Left column: Cell Type-Specificity Levels
                 column(
                   width = 6,
                   
                   h3("Cell Type-Specificity Levels"),
                   p(HTML("CEAM provides three levels of specificity, reflecting different stringency and reference panel sizes. 
           Criteria for including CpGs in these cell type-specific panels were based on median methylation values and/or significant differences assessed through linear mixed-effects modeling of M-values per cell type.
           Each level was constructed from cell-sorted DNAm data across two independent cohorts and validated in simulations.")),
                   
                   # High-Specificity Panels
                   h4(HTML("<b>1. High-Specificity Panels (Most Stringent)</b>")),
                   tags$ul(
                     tags$li(HTML("<b>Criteria:</b> Intermediate methylation (0.1 < β < 0.9) in only one cell type; ≥ 0.1 absolute methylation difference compared to all other cell types")),
                     tags$li(HTML("<b>Best used for:</b> Cleanest interpretation, Most robust cell-type attribution, Directionality analysis (hyper/hypo)"))
                   ),
                   
                   # Medium-Specificity Panels
                   h4(HTML("<b>2. Medium-Specificity Panels (Moderate Stringency)</b>")),
                   tags$ul(
                     tags$li(HTML("<b>Criteria:</b> Intermediate methylation in 1–3 cell types; CpGs may map to multiple cell types; Larger, more inclusive panels")),
                     tags$li(HTML("<b>Best used for:</b> Exploratory analyses, Detecting broader epigenetic patterns, Situations where high-specificity sets are too small or stringent"))
                   ),
                   
                   # Low-Specificity Panels
                   h4(HTML("<b>3. Low-Specificity Panels (Most Inclusive)</b>")),
                   tags$ul(
                     tags$li(HTML("<b>Criteria:</b> Intermediate methylation in target cell type; Significantly different from all other types (GLMM-based); Includes all CpGs from high- and medium-specificity panels")),
                     tags$li(HTML("<b>Best used for:</b> Maximizing sensitivity, Broad screening across cell types, Caution required due to potential overlap and larger set sizes"))
                   ),
                   
                   p(HTML("<b>Note:</b> Enrichment at this level may reflect shared biology, not a uniquely specific signal"))
                 ),
                 
                 # Right column: Background Probe Universes
                 column(
                   width = 6,
                   
                   h3("Background Probe Universes"),
                   p(HTML("CEAM offers two different backgrounds for enrichment analysis depending on the array used in your analysis. 
                          <br><br> 
                          <b> EPIC background </b> is the intersection of all probes present after pre-processing of the two cohorts used for the construction of these CpG panels 
                          <br><br> 
                          <b> 450K background </b> is the intersection of all probes present on a 450K array after removal of problematic probes (cross-hybridising, SNPs, etc.) and the EPIC background")),
                 )
               ),
               
               br(),
               h4("Citation"),
               tags$blockquote(
                 "Müller J, Laroche V, Imm J, Weymouth L, Harvey J, Smith AR, et al. 
                 A Cell Type Enrichment Analysis Tool for Brain DNA Methylation Data (CEAM). 
                 bioRxiv; 2025. p. 2025.07.08.663671. Available from: https://www.biorxiv.org/content/10.1101/2025.07.08.663671v1."
               )
             )
           )
         )),


# ---- PAGE 2: ORA Analysis ----
tabPanel(title = "ORA Analysis",
         fluidPage(
           rclipboardSetup(),  # Initialize clipboard support

    DTOutput("result_table"),
    fluidRow(
      column(
        width = 3,
        wellPanel(
          tags$h4("Input settings"),
          tags$strong("CpG list"),
          textAreaInput(
            inputId = "cpg_text",
            label   = NULL,
            placeholder = "Paste one probe ID per line",
            rows    = 6
          ),
          fileInput(
            inputId = "cpg_file",
            label   = "or upload CpG list",
            multiple = FALSE,
            accept   = c(".txt", ".csv", ".tsv")
          ),
          # numericInput(
          #   inputId = "min_set_size",
          #   label = "minimum overlap filter",
          #   value = 0
          # ),
          tags$hr(),
          tags$strong("Background list"),
          textAreaInput(
            inputId = "bg_text",
            label   = NULL,
            placeholder = "Paste one probe ID per line",
            rows    = 6
          ),
          fileInput(
            inputId = "bg_file",
            label   = "or upload background list",
            multiple = FALSE,
            accept   = c(".txt", ".csv", ".tsv")
          ),
          fluidRow(
            column(
              width = 6,
              actionButton("load_epic", "EPIC", width = "100%")
            ),
            column(
              width = 6,
              actionButton("load_450k", "450K", width = "100%")
            )
          ),
          tags$hr(style = "margin-top: 10px; margin-bottom: 0px;"),
          div(
            style = "display: flex; justify-content: space-between; align-items: flex-start; gap: 20px;",
            
            # LEFT: Specificity radio buttons
            div(
              style = "flex: 1;",
              tags$strong("Specificity"),
              radioButtons(
                inputId = "confidence_level",
                label   = NULL,
                choices = list(
                  "High Specificity"   = 1,
                  "High Specificity (with sub-levels)" = 2,
                  "Medium Specificity" = 3,
                  "Low Specificity"    = 4
                ),
                selected = 1
              )
            ),
            
            # RIGHT: Minimum Overlap Filter (compact inline style)
            div(
              style = "flex: 0 0 120px; margin-top: 23px;",
              tags$strong("Min. overlap"),
              numericInput(
                inputId = "min_set_size",
                label = NULL,
                value = 0,
                width = "100%"
              )
            )
          ),
          tags$hr(style = "margin-top: 10px; margin-bottom: 10px;"),
          actionButton("analyze", "Analyze", width = "100%"),
          tags$hr(style = "margin-top: 10px; margin-bottom: 10px;"),
          actionButton("load_example", "Load Example", width = "100%")
        )
      ),
      column(
        width = 9,  
        fluidRow(
          column(width = 12,
                 div(style = "text-align: right; padding-top: 20px;",
                     tags$img(src = "Logo.png", height = "80px", alt = "Logo not found :(")
                 )
          )
        ),
        fluidRow(
          column(
            width = 12,
            plotOutput("upset_plot", height = "400px")
          )
        ),
        fluidRow(
          column(
            width = 12,
            DTOutput("result_table")
          )
        ),
        # Add this row for download buttons, bottom-right aligned
        fluidRow(
          column(
            width = 12,
            div(
              style = "display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px;",
              downloadButton("download_svg", "Download Plot (.svg)"),
              downloadButton("download_csv", "Download Table (.csv)")
            )
          )
        ),
        ## FOOTER as simple aligned text
        fluidRow(
          column(
            width = 12,
            div(
              style = "
        max-width: 800px;
        margin: 30px auto 10px auto;
        text-align: center;
        line-height: 1.4;
      ",
              "See the complete manuscript: ",
              tags$a(
                "Joshua Müller, Valentin Laroche, Jennifer Imm, Luke Weymouth, Joshua Harvey, Adam R. Smith, Daniel van den Hove, Katie Lunnon, Rachel Cavill, Ehsan Pishva. doi: 10.1101/2025.07.08.663671",
                target = "_blank",
                href = "https://doi.org/10.1101/2025.07.08.663671",
                style = "font-weight: bold; text-decoration: underline;"
              )
            )
          )
        )
      )
    )
  )
)

) # for the ui

# ---- Server ----
server <- function(input, output, session) {
  # Reactive: CpG input vector
  cpg_list <- reactiveVal(character(0))
  observeEvent(input$cpg_file, {
    lines <- readLines(input$cpg_file$datapath)
    lines <- lines[nzchar(lines)]
    lines <- unlist(strsplit(lines, "[,\t\r\n]+"))
    lines <- gsub("\"|,| |\t", "", lines)
    lines <- grep("^cg\\d+$", lines, value = TRUE)
    updateTextAreaInput(
      session,
      "cpg_text",
      value = paste(lines, collapse = "\n")
    )
  })
  observeEvent(input$cpg_text, {
    txt <- unlist(strsplit(input$cpg_text, "[,\t\r\n]+"))
    txt = gsub("\"|,| |\t","",x = txt)
    txt <- txt[nzchar(txt)]
    cpg_list(txt)
  })
  # cpg_list <- reactive({
  #   if (!is.null(input$cpg_file)) {
  #     df <- readLines(input$cpg_file$datapath)
  #     #@RRR make sure gsub("\"|,| |\t","",x = df ) is in
  #     df <- df[nzchar(df)]
  #     return(df)
  #   }
  #   txt <- txt[nzchar(txt)]
  #   txt <- unlist(strsplit(input$cpg_text, "[\r\n,\t]+"))
  #   txt <- gsub("\"|,| |\t|\"","",x = txt )
  #   txt <- grep("^cg\\d+$", txt, value = TRUE)
  #   txt
  # })
  
  # After defining cpg_list reactive, add:
  
  # Reactive: Background vector
  bg_list <- reactiveVal(character(0))
  # After defining bg reactive, add:
  observeEvent(input$bg_file, {
    lines <- readLines(input$bg_file$datapath)
    lines <- lines[nzchar(lines)]
    lines <- unlist(strsplit(lines, "[,\t\r\n]+"))
    lines <- gsub("\"|,| |\t", "", lines)
    lines <- grep("^cg\\d+$", lines, value = TRUE)
    updateTextAreaInput(
      session,
      "bg_text",
      value = paste(lines, collapse = "\n")
    )
  })
  observeEvent(input$bg_text, {
    txt <- unlist(strsplit(input$bg_text, "[\r\n]+"))
    txt = gsub("\"|,| |\t","",x = txt )
    txt <- txt[nzchar(txt)]
    bg_list(txt)
  })
  
  observeEvent(input$load_450k, {
    # Assumes "450k_background.txt" exists in app directory
    bg450k <- fread("background_450k.txt", header = FALSE)[[1]]
    bg450k <- bg450k[nzchar(trimws(bg450k))]
    bg_list(bg450k)
    #Update bg_text input with the loaded file
    updateTextAreaInput(
      session,
      "bg_text",
      value = paste(bg450k, collapse = "\n")
    )
  })
  
  observeEvent(input$load_epic, {
    # Assumes "EPIC_background.txt" exists in app directory
    epic <- fread("EPIC_background.txt", header = FALSE)[[1]]
    epic <- epic[nzchar(trimws(epic))]
    bg_list(epic)
    # Update bg_text input with the loaded file
    updateTextAreaInput(
      session,
      "bg_text",
      value = paste(epic, collapse = "\n")
    )
  })

  observeEvent(input$load_example, {
    example_cpgs <- fread("example_input.txt", header = FALSE)[[1]]
    example_bg   <- fread("example_bg.txt", header = FALSE)[[1]]
    updateTextAreaInput(
      session,
      "cpg_text",
      value = paste(example_cpgs, collapse = "\n")
    )
    updateTextAreaInput(
      session,
      "bg_text",
      value = paste(example_bg, collapse = "\n")
    )
    bg_list(example_bg)
  })
  observeEvent(input$analyze, {
    min_val <- input$min_set_size
    })
  
  # Run ORA on analyze
  ora_result <- eventReactive(input$analyze, {
    req(cpg_list(), bg_list())
    CpG_ORA(
      input            = cpg_list(),
      background       = bg_list(),
      confidence_level = as.numeric(input$confidence_level)
    )
  })
  output$result_table <- renderDT({
    req(ora_result())
    dat <- ora_result()
    
    # Create copy button column
    dat$copy <- sprintf(
      '<button class="copy-btn btn btn-sm btn-default" style="margin-left: 10px;" data-clipboard-text="%s">Copy</button>',
      gsub('"', '"', dat$`Enriched CpGs`)  # Escape double quotes
    )
    
    # Truncate Enriched CpGs column
    dat$truncated_text <- mapply(function(x, y) {
      # Split the CpGs by newline and count them
      cpg_list <- strsplit(x, "\n")[[1]]
      
      # If there are more than 3 CpGs, show first three and add ellipsis
      if (length(cpg_list) > 3) {
        paste0(paste(cpg_list[1:3], collapse = "\n"), "\n...")
      } else {
        x
      }
    }, dat$`Enriched CpGs`, dat$copy)
    
    # Display truncated version but keep full text for copying
    dat$`Enriched Probes` <- dat$truncated_text
    
    # Render the table
    datatable(
      dat[,c("Enriched Probes", "copy", colnames(dat)[2:7])],
      escape = FALSE,
      options = list(
        pageLength = 12,
        autoWidth = FALSE,
        scrollX = TRUE,
        columnDefs = list(
          list(targets = 1, className = "dt-left"),
          list(targets = 2, orderable = FALSE, searchable = FALSE),
          list(targets = 2:7, className = "dt-center")  # Center-align numeric columns
        )
      ),
      callback = JS("
      $(document).ready(function() {
        var clipboard = new ClipboardJS('.copy-btn');
        clipboard.on('success', function(e) {
          $(e.trigger).tooltip('show').attr('data-original-title', 'Copied!');
          setTimeout(function() {
            $(e.trigger).tooltip('hide');
          }, 2000);
        });
      });
    ")
    )%>%
      formatSignif(
        columns = c("P-value", "Expected Count", "qvalue"),  # <- replace with your numeric column names
        digits = 4
      )%>% 
      formatStyle(
        columns = colnames(dat),   # or specific columns
        valueColumns = "Overlap",
        backgroundColor = JS(
          sprintf(
            "value < %d ? '#e0e0e0' : null",
            input$min_set_size
          )
        ),
        color = JS(
          sprintf(
            "value < %d ? '#777777' : null",
            input$min_set_size
          )
        )
      )
  })
  output$upset_plot <- renderPlot({
    req(ora_result())
    min_val <- input$min_set_size
    plot_CpG_UpSet(ora_result(), min_set_size = min_val)
  })
  
  output$download_svg <- downloadHandler(
    filename = function() {
      "UpSet_Enrichment.svg"
    },
    content = function(file) {
      svg(file)
      print(plot_CpG_UpSet(ora_result()))
      dev.off()
    }
  )
  output$download_csv <- downloadHandler(
    filename = function() {
      "DNAm_enrichment_res.csv"
    },
    content = function(file) {
      write.csv(ora_result(), file = file, row.names = T)
      
    }
  )
}
shinyApp(ui, server)